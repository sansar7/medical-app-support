Entirely computer-generated geometric phantom. No patient data.
96 x 96 x 64 voxels, 0.5 mm spacing. Not anatomy or clinical validation.
Open this folder with Dental CBCT Studio.
